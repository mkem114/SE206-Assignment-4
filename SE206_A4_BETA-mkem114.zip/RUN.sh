#! /bin/bash
/usr/lib/jvm/jdk8/bin/java -cp ./out/production/SE206-Assignment-4/ voxspell.gui.App & disown
